<?php
$redis  = new Redis();
$er = false;
try{
$connected = $redis->connect('127.0.0.1', 6379);
if(!$connected){
$er = true;
}
}catch(Exception $e) {
$er = true;
}
if($er){
if(!strstr(shell_exec("sudo redis-cli ping"),"PONG")){
shell_exec('sudo redis-server /etc/redis/redis.conf > /dev/null 2>/dev/null &');
sleep(1);
try{
$connected = $redis->connect('127.0.0.1', 6379);
if(!$connected){
exit;
}
}catch(Exception $e) {
exit;
}
}else{
exit;
}
}
if($argv[1] == "get"){
echo $redis->hget("users",$argv[2]);
}elseif($argv[1] == "set"){
$redis->hset("users",$argv[2],time()+5);
}
exit;