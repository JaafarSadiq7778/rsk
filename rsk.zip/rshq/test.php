<?php
echo file_get_contents("datas/5200567520.json");
