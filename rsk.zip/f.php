<?php
echo count(json_decode(file_get_contents("x.json")));

