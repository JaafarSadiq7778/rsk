<?php
$del = array();
define('API_KEY','1149409334:AAFyTPL6gnKa27xukxUravtNAPFcmlnPtFY');
function javan($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
$x = json_decode($res);
return $x;
}
}
define('API_KEY2','1340007319:AAH3K9yVdu3ZgbfPHwWR9HlWRy_FIbEMwJM');
function javan2($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY2."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
$x = json_decode($res);
return $x;
}
}
$data = json_decode(file("channels.json")[0],1);
$ct = count(array_keys($data));
$keys = array_keys($data);
for($i=0; $i<count($keys); $i++){
$channel = strtoupper($keys[$i]);
$idbot = explode(":",API_KEY)[0];
$j = javan("getchatmember",[
"chat_id"=>"@".$channel,
"user_id"=>$idbot,
]);
if(@$j->result->status != "administrator" and @isset($j->result->status)){
$chs = json_decode(file_get_contents("channels/".$channel.".json"),1);
$poin = $chs["points"];
$ad = $chs["admin"];
unlink("channels/".$channel.".json");
$json = json_decode(file_get_contents("datas/".$ad.".json"),1);
$ex = $json["points"] + $poin;
$json["points"] = $ex;
unset($json["my_channels"][$channel]);
file_put_contents("datas/".$ad.".json",json_encode($json));
$del[] = $channel;
javan("sendmessage",[
"chat_id"=>$ad,
"text"=>"تم حذف هذهِ القناة ( @[".$channel."] )،
من قائمة القنوات الفعالة ⭐،
بسبب عدم رفع هذا البوت ( @oeebot ) أدمن في القناة.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"🛎 طلباتي 🛎",'callback_data'=>'active']],
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
javan("sendmessage",[
"chat_id"=>"-1001489313802",
"text"=>"تم حذف هذهِ القناة ( [@".$channel."] )،
من قائمة القنوات الفعالة ⭐.",
"parse_mode"=>"markdown",
]);
javan2("sendmessage",[
"chat_id"=>$ad,
"text"=>"تم حذف هذهِ القناة ( @[".$channel."] )،
من قائمة القنوات الفعالة ⭐،
بسبب عدم رفع هذا البوت ( @oeebot ) أدمن في القناة.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"🛎 طلباتي 🛎",'callback_data'=>'active']],
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
javan2("sendmessage",[
"chat_id"=>"-1001489313802",
"text"=>"تم حذف هذهِ القناة ( [@".$channel."] )،
من قائمة القنوات الفعالة ⭐.",
"parse_mode"=>"markdown",
]);
echo $channel." => Deleted\n";
}
}
for($i=0; $i<count($keys); $i++){
$channel = strtoupper($keys[$i]);
@$get = file_get_contents("channels/".strtoupper($keys[$i]).".json");
$getj = json_decode($get,1);
if($getj["points"] == 0 and isset($getj["points"])){
@$json = json_decode(file_get_contents("datas/".$getj["admin"].".json"),1);
$key = array_keys(array_change_key_case($json["my_channels"],CASE_UPPER));
$nj = array_search($channel,$key)+1;
unset($json["my_channels"][$channel]);
file_put_contents("datas/".$getj["admin"].".json",json_encode($json));
$getl = file_get_contents("https://t.me/".$channel);
$sn = str_replace(" ","",explode(" m",explode('<div class="tgme_page_extra">',$getl)[1])[0]);
$ready = gmdate("H:i:s d-m-Y", $getj["time"]);
$now = time() - $getj["time"];
$dt1 = new DateTime("@0");
$dt2 = new DateTime("@$now");
$xtime = $dt1->diff($dt2)->format('%aD:%hH:%iM:%sS');
javan("sendmessage",[
"chat_id"=>$getj["admin"],
"text"=>"أكتمل الطلب رقم *".$nj."* 🛎
عدد المشتركين المطلوبين *".floor($getj["points_o"]/3)."* 👤
الى القناة [@".$channel."] 😼✌🏻،
عدد مشتركين القناة الآن *".$sn."* 🏆،
وقت البدء: ".$ready." 🔥،
استغرق: ".$xtime." 🥇.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"🛎 طلباتي 🛎",'callback_data'=>'active']],
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
javan2("sendmessage",[
"chat_id"=>$getj["admin"],
"text"=>"أكتمل الطلب رقم *".$nj."* 🛎
عدد المشتركين المطلوبين *".floor($getj["points_o"]/3)."* 👤
الى القناة [@".$channel."] 😼✌🏻،
عدد مشتركين القناة الآن *".$sn."* 🏆،
وقت البدء: ".$ready." 🔥،
استغرق: ".$xtime." 🥇.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"🛎 طلباتي 🛎",'callback_data'=>'active']],
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
$njj = array_search($channel,$keys)+1;
javan("sendmessage",[
"chat_id"=>"-1001489313802",
"text"=>"أكتمل الطلب رقم *".$njj."* 🛎
عدد المشتركين المطلوبين *".floor($getj["points_o"]/3)."* 👤
الى القناة [@".$channel."] 😼✌🏻،
عدد مشتركين القناة الآن *".$sn."* 🏆،
وقت البدء: ".$ready." 🔥،
استغرق: ".$xtime." 🥇.",
"parse_mode"=>"markdown",
]);
unlink("channels/".strtoupper($keys[$i]).".json");
$del[] = strtoupper($keys[$i]);
echo strtoupper($keys[$i])." => Deleted\n";
}
}
$data = json_decode(file("channels.json")[0],1);
$data = array_diff_key($data, array_flip($del));
$file = fopen("channels.json","w");
fwrite($file, json_encode($data));
fclose($file);
$data = json_decode(file("channels.json")[0],1);
$keys = array_keys($data);
for($i=0; $i<count($keys); $i++){
$channel = strtoupper($keys[$i]);
@$get = file_get_contents("channels/".strtoupper($keys[$i]).".json");
$chs = json_decode($get,1);
if(!isset($chs["points"])){
$chs["points"] = 120;
$chs["points_o"] = 120;
$chs["admin"] = 350926338;
$chs["time"] = time();
file_put_contents("channels/".$channel.".json",json_encode($chs));
}
}
$ads = json_decode(file_get_contents("ads.json"),1);
if($ads["day"] != date("d")){
$ads = array();
$ads["day"] = date("d");
for($i=0; $i<20; $i++){
$r = time();
$code = base64_encode($r."&_3&_javanforever");
$ads["array"][] = file_get_contents("http://ouo.io/api/HkIUqXrW?s=https://t.me/oeebot?start=code_".$code);
$ads["codes"][] = $code;
sleep(1);
}
file_put_contents("ads.json",json_encode($ads));
}