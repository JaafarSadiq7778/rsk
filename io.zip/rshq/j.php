<?php
exit;
date_default_timezone_set('Asia/Baghdad');
define('API_KEY','1149409334:AAFyTPL6gnKa27xukxUravtNAPFcmlnPtFY');
$owner_chs = array("ShakeBots"=>1,"UUUUv"=>1);
$blocked = array("Y4BBOT"=>1,"YKBBoT"=>1,"AudiodBot"=>1,"HYVBOT"=>1);
function javan($method,$datas=[],$xx=false){
$y = false;
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
$x = json_decode($res);
if($xx){
return $xx;
}
global $from_id;
global $admin_id;
if($from_id == null){
global $from_id2;
$from_id = $from_id2;
}
if($from_id == null){
return $x;
}
@$admin = json_decode(file_get_contents("admin.json"),1);
$bthoth = $admin["bthoth"];
$keys = array_keys($bthoth);
foreach($keys as $key){
$bth = $bthoth[$key];
$user = json_decode(file_get_contents("datas/".$from_id.".json"),1);
if(!in_array($key,$user["bthoth"])){
$user["bthoth"][] = $key;
file_put_contents("datas/".$from_id.".json",json_encode($user));
$y = true;
break;
}
}
if($y){
if(isset($bth["key"])){
return javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>$bth["text"],
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"♻️ تحقق من الانضمام ♻️",'callback_data'=>$bth["key"]]],
]
])
],$x);
}else{
return javan('forwardMessage',[
'chat_id'=>$from_id,
'from_chat_id'=>$admin_id,
'message_id'=>$key,
],$x);
}
}
return $x;
}
}
if(javan("getwebhookinfo")->result->pending_update_count > 50){
exit;
}
if(@$argv[1] == "javan" or @$_GET["backup"] == "yes"){
javan("senddocument",[
'chat_id'=>"-1001492645723",
'document'=>new CURLFile("channels.json"),
]);
system('screen -dmS save php x.php');
$zipFile = "channels.zip";
$zipArchive = new ZipArchive();
$zipArchive->open($zipFile, (ZipArchive::CREATE | ZipArchive::OVERWRITE));
$zipArchive->addGlob("channels/*.json");
$zipArchive->close();
javan("senddocument",[
'chat_id'=>"-1001492645723",
'document'=>new CURLFile("channels.zip"),
]);
@unlink("channels.zip");
exit;
}
function checkk($user_id){
$user = json_decode(file_get_contents("datas/".$user_id.".json"),1);
if(is_array($user["last_join"])){
foreach($user["last_join"] as $join){
$join = trim($join,"@");
$id = javan("getchat",[
"chat_id"=>"@".$join,
])->result->id;
if(!strstr(json_encode($user["channels_join"]),'"'.strtoupper($join).'\/'.$id) and $join != null){
if(checkjoin($user_id,$join,1)){
$id = javan("getchat",[
"chat_id"=>"@".$join,
])->result->id;
$user["points"] = $user["points"] + 2;
$user["channels_join"][] = strtoupper($join."/".$id);
$ss = strtoupper($join);
$chano .= "➖ @".$ss."\n";
$key = array_search($ss,$user["last_join"]);
unset($user["last_join"][$key]);
$user["last_join"] = array_values($user["last_join"]);
file_put_contents("datas/".$user_id.".json",json_encode($user));
$chs = json_decode(file_get_contents("channels/".$ss.".json"),1);
if($chs["points"] >= 3){
$chs["points"] = $chs["points"] - 3;
file_put_contents("channels/".$ss.".json",json_encode($chs));
}
}
}
}
}else{
$id = javan("getchat",[
"chat_id"=>"@".$user["last_join"],
])->result->id;
if(!strstr(json_encode($user["channels_join"]),'"'.strtoupper($user["last_join"]).'\/'.$id) and $user["last_join"] != null){
if(checkjoin($user_id,$user["last_join"],1) and $user["last_join"] != null){
$id = javan("getchat",[
"chat_id"=>"@".trim($user["last_join"],"@"),
])->result->id;
$user["points"] = $user["points"] + 2;
$user["channels_join"][] = strtoupper(trim($user["last_join"],"@")."/".$id);
$ss = strtoupper(trim($user["last_join"],"@"));
$chano .= "➖ @".$ss."\n";
$user["last_join"] = null;
file_put_contents("datas/".$user_id.".json",json_encode($user));
$chs = json_decode(file_get_contents("channels/".$ss.".json"),1);
if($chs["points"] >= 3){
$chs["points"] = $chs["points"] - 3;
file_put_contents("channels/".$ss.".json",json_encode($chs));
}
}
}
}
if($chano != null){
$st = "🆔: [".$user_id."](tg://user?id=".$user_id."),
Points 💰: *".$user["points"]."*,
";
$e = $st."Join 🔥:\n\n[".$chano."]";
javan("sendmessage",[
"chat_id"=>"-1001492645723",
"text"=>$e,
"parse_mode"=>"markdown",
]);
}
}
function randchannels($user_id,$list,$rt=null){
$channels = array_keys(json_decode(file("channels.json")[0],1));
$user = json_decode(file_get_contents("datas/".$user_id.".json"),1);
$joinned = array_change_key_case($user["channels_join"],CASE_UPPER);
if($rt != null){
$rr = array_search($rt,$channels)+1;
}else{
$rr = 0;
}
for($i=$rr; $i<count($channels); $i++){
$channel = strtoupper($channels[$i]);
$id = javan("getchat",[
"chat_id"=>"@".$channel,
])->result->id;
if(!strstr(json_encode($joinned),'"'.$channel.'\/'.$id) and !in_array("@".$channel,$list)){
$channel2 = json_decode(file_get_contents("channels/".$channel.".json"),1);
if($channel2["points"] == 0){
continue;
}elseif($channel2["points"] <= 3){
$channel2["points"] = 3;
file_put_contents("channels/".$channel.".json",json_encode($channel2));
}
if(!checkjoin($user_id,$channel)){
return "@".$channel;
}
}
}
return null;
}
function checkjoin($user_id,$channel,$x=false){
global $blocked;
if(in_array(strtoupper(trim($channel,"@")),array_keys($blocked))){
return true;
}
$idbot = explode(":",API_KEY)[0];
$j = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@".trim($channel,"@")."&user_id=".$idbot),1);
if($j["result"]["status"] == "administrator"){
$j = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getChatMember?chat_id=@".trim($channel,"@")."&user_id=".$user_id),1);
if($j["result"]["status"] == "left"){
return false;
}else{
return true;
}
}else{
return true;
}
}
function check2($user_id,$message_id){
global $admin_channel;
if(checkjoin($user_id,$admin_channel) == false){
$e = "يجب ان تنضم في قناة البوت اولاً @[".$admin_channel."] 👨🏻‍💻🍂 التي تحتوي ع المشاكل التي قد تواجهها والمعلومات التي ستساعدك في زيادة قناتك بشكل جيد وأخر اخبار وعروض البوت ,ويتم نشر فيها القنوات التي تعطي 10 نقاط مقابل الانضمام فيها فلا تقم بكتم القناة ✨.";
javan("editmessagetext",[
"chat_id"=>$user_id,
"message_id"=>$message_id,
"text"=>$e,
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"♻️ تحقق من الانضمام ♻️",'callback_data'=>'collect']],
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
exit;
}
}
@$update = json_decode(file_get_contents('php://input'));
if(!isset($update)){
exit;
}
$admin = 1149898284;
$admin_id = $admin;
$admin_username = "TTT7T";
$bot_username = "oeebot";
$admin_channel = "ShakeBots";
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$first_name = $message->from->first_name;
$first_name2 = $update->callback_query->from->first_name;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id; 
$from_id2 = $update->callback_query->from->id; 
$message_id = $update->callback_query->message->message_id; 
$data = $update->callback_query->data; 
$membercall = $update->callback_query->id;
$inline = $update->inline_query;
if($from_id == 350926338 or $from_id == $admin){
@$admin = json_decode(file_get_contents("admin.json"),1);
if(strstr($text,"حظر ")){
$text = strtoupper(str_replace("@","",explode("حظر ",$text)[1]));
if(!in_array($text,$admin["kicks"])){
$admin["kicks"][] = $text;
file_put_contents("admin.json",json_encode($admin));
}
javan('sendMessage',[ 
'chat_id'=>$from_id, 
'text'=>"تم حظر القناة.",
'parse_mode'=> 'markdown', 
]); 
exit; 
}
if(strstr($text,"الغاء ")){
$text = strtoupper(str_replace("@","",explode("الغاء ",$text)[1]));
$channels = array_flip($admin["kicks"]);
unset($channels[$text]);
$admin["kicks"] = array_keys($channels);
file_put_contents("admin.json",json_encode($admin));
javan('sendMessage',[ 
'chat_id'=>$from_id, 
'text'=>"تم الغاء حظر القناة.",
'parse_mode'=> 'markdown', 
]); 
exit; 
}
$startAdmin = "*👋┇مرحباً عزيزي الادمن،\n⬇️┇اختار ماتريد من القائمه في الاسفل.*";
$seto = [
[["text"=>"عدد المستخدمين 🎖"]],
[["text"=>"معلومات مستخدم 👤"]],
[["text"=>"حذف نقاط 👤"],["text"=>"أضافة نقاط 👤"]],
[["text"=>"قائمة الهدايا 🎰"]],
[["text"=>"حذف جميع الهدايا 🎰"],["text"=>"حذف هدية 🎰"]],
[["text"=>"حذف قناة ⭐"],["text"=>"القنوات الفعالة ⭐"]],
[["text"=>"تعطيل طلب مشتركين 🕉"],["text"=>"تفعيل طلب مشتركين 🕉"]],
[["text"=>"تفعيل طلب مشتركين مساءً 🕉"]],
[["text"=>"قائمة البثوث 📺"],["text"=>"بدء بث جديد 📺"]],
[["text"=>"أذاعه 📣"]],
];
if($admin["step"] == "bth_done"){
if($text == "لا"){
$admin["step"] = null;
$admin["bth_key"] = null;
file_put_contents("admin.json",json_encode($admin));
javan('sendMessage',[ 
'chat_id'=>$from_id, 
'text'=>"تم الغاء البث بنجاح.", 
'parse_mode'=> 'markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true, 
'keyboard'=>$seto 
]) 
]); 
exit; 
} 
if($text == "نعم"){ 
$users = count(glob('./datas/*.*'))+1;
javan('sendMessage',[ 
'chat_id'=>$from_id, 
'text'=>"تم البث بنجاح الى: *".$users."* مشترك.",
'parse_mode'=> 'markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true, 
'keyboard'=>$seto 
]) 
]); 
if($admin["bth_key"] != null){
$admin["bthoth"][$admin["bth_id"]]["key"] = $admin["bth_key"];
}
$admin["bthoth"][$admin["bth_id"]]["name"] = $admin["bth_name"];
$admin["bthoth"][$admin["bth_id"]]["text"] = $admin["bth_text"];
$admin["bth_key"] = null;
file_put_contents("admin.json",json_encode($admin));
exit; 
} 
}
if($admin["step"] == "doneaz"){
if($text == "لا"){
$admin["step"] = null;
file_put_contents("admin.json",json_encode($admin));
javan('sendMessage',[ 
'chat_id'=>$from_id, 
'text'=>"تم الغاء الأذاعه بنجاح.", 
'parse_mode'=> 'markdown', 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true, 
'keyboard'=>$seto 
]) 
]); 
exit; 
} 
if($text == "نعم"){ 
shell_exec("sudo screen -dmS javan php aza3a.php ".$from_id." ".API_KEY); 
$admin["step"] = null;
file_put_contents("admin.json",json_encode($admin));
exit; 
} 
}
if(strtolower($text) == "/admin" or $text == "رجوع 🔙"){
$admin["step"] = null;
file_put_contents("admin.json",json_encode($admin));
javan('sendMessage',[
'chat_id'=>$from_id,
'text'=>$startAdmin,
'parse_mode'=> 'markdown',
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>$seto
])
]);
exit;
}
if ($text == "بدء بث جديد 📺"){
javan('sendMessage',[
'chat_id'=>$from_id,
'text'=>"قم بأرسال عنوان للبث  📺.",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>$seto
])
]);
$admin["step"] = "send_bth0";
file_put_contents("admin.json",json_encode($admin));
exit;
}
if(strstr($text,"||") and strstr($text,"#Jv-")){
$id = explode("||",$text)[0];
$id = explode("-",$id)[1];
$id = str_replace(" ","",$id);
$x = 0;
foreach(glob('./datas/*.*') as $filename){
$user = json_decode(file($filename)[0],1);
if(in_array($id,$user["bthoth"])){
$x++;
}
}
$all = count(glob('./datas/*.*'))+1;
$n = $all - $x;
javan('sendMessage',[
'chat_id'=>$from_id,
'text'=>"تم البث لـ *".$x."* مستخدم،
من اصل *".$n."* مستخدم.

رسالة البث:",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text' => "#Ri-".$id." || حذف"]],
[["text"=>"رجوع 🔙"]],
]
])
]);
javan('forwardMessage',[
 'chat_id'=>$from_id,
 'from_chat_id'=>$from_id,
'message_id'=>$id,
 ]);
exit;
}
if(strstr($text,"||") and strstr($text,"#Ri-")){
$id = explode("||",$text)[0];
$id = explode("-",$id)[1];
$id = str_replace(" ","",$id);
unset($admin["bthoth"][$id]);
file_put_contents("admin.json",json_encode($admin));
javan('sendMessage',[
'chat_id'=>$from_id,
'text'=>"تم الحذف بنجاح 🔥.",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>$seto
])
]);
exit;
}
if($text == "قائمة البثوث 📺"){
$keys = array_keys($admin["bthoth"]);
for($i=0; $i<count($keys); $i++){
$key = $keys[$i];
$rep[] = [['text' => "#Jv-".$key." || ".$admin["bthoth"][$key]["name"]]];
}
$rep[] = [["text"=>"رجوع 🔙"]];
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"هذهِ قائمة البثوث الخاصة بك 📺:",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>$rep
])
]);
exit;
}
if($text == "عدد المستخدمين 🎖"){
$users = count(glob('./datas/*.*'))+1;
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"Count Users: *".$users."* 👤.",
"parse_mode"=>"markdown",
]);
exit;
}
if($text == "حذف هدية 🎰"){
$admin["step"] = "delg1&";
file_put_contents("admin.json",json_encode($admin));
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"قم بأرسال الكود المطلوب 🎰.",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
exit;
}
if($text == "تعطيل طلب مشتركين 🕉"){
$admin["sell"] = "off";
file_put_contents("admin.json",json_encode($admin));
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"تم تعطيل طلب المشتركين بنجاح 🕉.",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
exit;
}
if($text == "تفعيل طلب مشتركين 🕉"){
$admin["sell"] = "on";
file_put_contents("admin.json",json_encode($admin));
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"تم تفعيل طلب المشتركين بنجاح 🕉.",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
exit;
}
if($text == "تفعيل طلب مشتركين مساءً 🕉"){
$admin["sell"] = "time";
file_put_contents("admin.json",json_encode($admin));
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"تم تفعيل طلب مشتركين مساءً بنجاح 🕉.",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
exit;
}
if($admin["step"] == "delg1&"){
$admin["step"] = null;
if(in_array($text,$admin["codes"])){
$key = array_search($text,$admin["codes"]);
unset($admin["codes"][$key]);
$admin["codes"] = array_values($admin["codes"]);
}
file_put_contents("admin.json",json_encode($admin));
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"تم حذف الكود المطلوب بنجاح 🎰.",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
exit;
}
if($text == "حذف جميع الهدايا 🎰"){
$admin["codes"] = array();
file_put_contents("admin.json",json_encode($admin));
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"تم حذف جميع الهدايا بنجاح 🎰.",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
exit;
}
if($text == "حذف نقاط 👤"){
$admin["step"] = "delu1&";
file_put_contents("admin.json",json_encode($admin));
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"قم بأرسال ID المستخدم 👤.",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
exit;
}
if($admin["step"] == "delu1&"){
if(file_get_contents("datas/".$text.".json") == null){
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"هذا الشخص غير موجود 👤.",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
}else{
$admin["step"] = "del2&".$text;
file_put_contents("admin.json",json_encode($admin));
@$json = json_decode(file_get_contents("datas/".$text.".json"),1);
if(!isset($json["points"])){
$json["points"] = "0";
}
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"عدد نقاط المستخدم: *".$json["points"]."*،

أرسل عدد النقاط ألتي تريد استقطاعها منه 👤.",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
}
exit;
}
if(strstr($admin["step"],"del2&")){
$id = explode("del2&",$admin["step"])[1];
@$json = json_decode(file_get_contents("datas/".$id.".json"),1);
if(!isset($json["points"])){
$ex = "0";
}else{
if($json["points"] < 1){
$ex = "0";
}else{
if($json["points"] - $text >= 0){
$ex = $json["points"] - $text;
}else{
$ex = "0";
}
}
}
$json["points"] = $ex;
file_put_contents("datas/".$id.".json",json_encode($json));
$admin["step"] = null;
file_put_contents("admin.json",json_encode($admin));
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"تم استقطاع النقاط بنجاح 👤.",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
exit;
}
if($text == "أضافة نقاط 👤"){
$admin["step"] = "sendu1&";
file_put_contents("admin.json",json_encode($admin));
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"قم بأرسال ID المستخدم 👤.",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);;
exit;
}
if($admin["step"] == "sendu1&"){
if(file_get_contents("datas/".$text.".json") == null){
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"هذا الشخص غير موجود 👤.",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
}else{
$admin["step"] = "sendu2&".$text;
file_put_contents("admin.json",json_encode($admin));
@$json = json_decode(file_get_contents("datas/".$text.".json"),1);
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"عدد نقاط المستخدم: *".$json["points"]."*،

أرسل عدد النقاط ألتي تريد أضافتها لهذا المستخدم 👤.",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
}
exit;
}
if(strstr($admin["step"],"sendu2&")){
$id = explode("sendu2&",$admin["step"])[1];
@$json = json_decode(file_get_contents("datas/".$id.".json"),1);
$ex = $json["points"] + $text;
$json["points"] = $ex;
file_put_contents("datas/".$id.".json",json_encode($json));
$admin["step"] = null;
file_put_contents("admin.json",json_encode($admin));
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"تم أضافة النقاط للمستخدم بنجاح 👤.",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
exit;
}
if($text == "حذف قناة ⭐"){
$admin["step"] = "delc&";
file_put_contents("admin.json",json_encode($admin));
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"قم بأرسال معرف القناة 💰.",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
exit;
}
if($admin["step"] == "delc&"){
$m3 = strtoupper(trim($text,"@"));
if(file_get_contents("channels/".$m3.".json") == null){
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"هذه القناة غير موجودة 💰.",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
}else{
$admin["step"] = null;
file_put_contents("admin.json",json_encode($admin));
unlink("channels/".$m3.".json");
$channels = json_decode(file("channels.json")[0],1);
unset($channels[$m3]);
$file = fopen("channels.json","w");
fwrite($file, json_encode($channels));
fclose($file);
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"تم حذف هذهِ القناة بنجاح 💰",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
}
exit;
}
if($text == "معلومات مستخدم 👤"){
$admin["step"] = "info&";
file_put_contents("admin.json",json_encode($admin));
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"قم بأرسال ID المستخدم 👤.",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
exit;
}
if($admin["step"] == "info&"){
if(file_get_contents("datas/".$text.".json") == null){
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"هذا الشخص غير موجود 👤.",
"parse_mode"=>"markdown",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
}else{
$admin["step"] = null;
file_put_contents("admin.json",json_encode($admin));
$json = json_decode(file_get_contents("datas/".$text.".json"),1);
if(isset($json["my_channels"])){
$keys = array_keys(array_change_key_case($json["my_channels"],CASE_UPPER));
$data = json_decode(file("channels.json")[0],1);
$channels = null;
$l = "0";
$done = array();
for($i=0; $i<count($keys); $i++){
if(isset($data[strtoupper($keys[$i])]) and !in_array(strtoupper($keys[$i]),$done)){
$done[] = strtoupper($keys[$i]);
$chs = json_decode(file_get_contents("channels/".strtoupper($keys[$i]).".json"),1);
$l++;
$z = floor($chs["points"]/3);
if($z == 0){
$z = "0";
}
$c = floor(($chs["points_o"] - $chs["points"])/3);
if($c == 0){
$c = "0";
}
$ready = gmdate("H:i:s d-m-Y", $chs["time"]);
$cc = array_search(strtoupper($keys[$i]),array_change_key_case(array_keys($data),CASE_UPPER))+1;
$channels .= "➖ القناة: [@".strtoupper($keys[$i])."] ⭐،
➖ تسلسل طلبه: *".$cc."* 💡،
➖ عدد الدخول: *".$c."* 👤،
➖ عدد المتبقين: *".$z."* 👤،
➖ العدد المطلوب: *".($z+$c)."* 👤،
➖ وقت البدء: *".($ready)."* 🔥.
----------------------------
";
}
}
}else{
$channels = "ليس لديه آي قناة تحت التمويل.";
}
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"عدد نقاط المستخدم: *".$json["points"]."*,
قنوات المستخدم التي تحت التمويل 💰:

".$channels,
'parse_mode'=>markdown,
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
}
exit;
}
if($text == "القنوات الفعالة ⭐"){
$data = json_decode(file("channels.json")[0],1);
$ct = count(array_keys($data));
$keys = array_keys($data);
$done = array();
for($i=0; $i<count($keys); $i++){
if(!in_array(strtoupper($keys[$i]),$done)){
$done[] = strtoupper($keys[$i]);
$chs = json_decode(file_get_contents("channels/".strtoupper($keys[$i]).".json"),1);
$l++;
$z = floor($chs["points"]/3);
if($z == 0){
$z = "0";
}
$con = "[".$chs["admin"]."](tg://user?id=".$chs["admin"].")";
$c = floor(($chs["points_o"] - $chs["points"])/3);
if($c == 0){
$c = "0";
}
$cc = $i+1;
$channels[] = "➖ [@".strtoupper($keys[$i])."] ⭐,\n➖ Number: *".$cc."* 💡,\n➖ Joinned: *".$c."* 👤,\n➖ Stay: *".$z."* 👤,\n➖ Original: *".($z+$c)."* 👤,\n➖ Admin: ".$con." 👨🏻‍🔧.\n➖➖➖➖➖➖➖➖\n";
}
}
$s = array_chunk($channels,18);
foreach($s as $channel2){
$channels2 = null;
foreach($channel2 as $channel){
$channels2 .= $channel;
}
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>$channels2,
"parse_mode"=>"markdown",
]);
}
exit;
}
if($text == "قائمة الهدايا 🎰"){
$keys = $admin["codes"];
if($keys[0] != null){
$done = array();
for($i=0; $i<count($keys); $i++){
if(!in_array($keys[$i],$done)){
$done[] = $keys[$i];
$l++;
$cod = base64_decode($keys[$i]);
$ex = explode("&_",$cod);
$username = "@[".$ex[2]."]";
$point = $ex[1];
$cc = $i+1;
$channels[] = "Code: `".$keys[$i]."`,\nNumber: *".$cc."*,\nChannel: ".$username.",\nPoint: *".$point."*.\n\n";
}
}
$s = array_chunk($channels,18);
foreach($s as $channel2){
$channels2 = null;
foreach($channel2 as $channel){
$channels2 .= $channel;
}
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>$channels2,
"parse_mode"=>markdown
]);
}
}else{
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"لا توجد هدايا في البوت 🎰.",
"parse_mode"=>markdown
]);
}
exit;
}
if($text == "أذاعه 📣"){
javan('sendMessage',[
'chat_id'=>$from_id,
'text'=>"قم بتوجيه المراد أذاعته ألى هنا 📣.",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
$admin["step"] = "sendf";
file_put_contents("admin.json",json_encode($admin));
exit;
}
if($admin["step"] == "send_bth0" ){ 
$admin["bth_name"] = $text;
$admin["step"] = 'send_bth';
file_put_contents("admin.json",json_encode($admin)); 
javan('sendMessage',[
'chat_id'=>$from_id,
'text'=>"قم بأرسال الرسالة المطلوب بثها 📺.",
'reply_markup'=>json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[["text"=>"رجوع 🔙"]],
]
])
]);
exit; 
}
if($admin["step"] == "send_bth" ){ 
$key = $message->reply_markup;
if($key != null){
$key = json_decode(json_encode($key),1);
$admin["bth_key"] = explode("start=",$key["inline_keyboard"][0][0]["url"])[1];
$admin["bth_text"] = $text;
$admin["bth_id"] = $message->message_id; 
}else{
$admin["bth_id"] = $message->message_id; 
}
$admin["step"] = 'bth_done';
file_put_contents("admin.json",json_encode($admin)); 
javan('sendMessage',[ 
'chat_id'=>$from_id, 
'text'=>"هل أنت متأكد من البث ؟", 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true, 
'keyboard'=>[ 
[["text"=>"لا"],["text"=>"نعم"]], 
] 
]) 
]);
exit; 
}
if($admin["step"] == "sendf"){ 
$admin["aza3a"] = $message->message_id; 
$admin["step"] = 'doneaz';
file_put_contents("admin.json",json_encode($admin)); 
javan('sendMessage',[ 
'chat_id'=>$from_id, 
'text'=>"هل أنت متأكد من الاذاعه ؟", 
'reply_markup'=>json_encode([ 
'resize_keyboard'=>true, 
'keyboard'=>[ 
[["text"=>"لا"],["text"=>"نعم"]], 
] 
]) 
]);
exit; 
}
}
if($inline){
$id = $inline->id;
$chat_id = $inline->from->id;
$query = $inline->query;
if(strstr($query,"add ") and count(explode(" ",$query)) == 3 and $chat_id == $admin_id or $chat_id == 350926338){
$ex = explode("add ",$query)[1];
$ex = explode(" ",$ex);
$username = trim($ex[0],"@");
$point = $ex[1];
$code = base64_encode($id."&_".$point."&_".$username);
$results[] = array(
"type"=>"article",
"id"=>base64_encode(rand(5,555)),
"title"=>"@".$username,
"description"=>"Developed by @Jvvvv.",
"input_message_content"=>array(
"message_text"=>"انضم في القناة @".$username." ✅،
واحصل على ".$point." نقطة 💰."
),
"reply_markup"=>array(
'inline_keyboard'=>array(
[['text'=>"♻️ تحقق من الانضمام ♻️",'url'=>"https://t.me/".$bot_username."?start=code_".$code]],
)
),
);
javan("answerInlineQuery",[
"inline_query_id"=>$id,
"results"=>json_encode($results)
]);
@$admin = json_decode(file_get_contents("admin.json"),1);
$admin["codes"][] = $code;
file_put_contents("admin.json",json_encode($admin));
}else{
$results[] = array(
"type"=>"article",
"id"=>base64_encode(rand(5,555)),
"title"=>"مشاركة الرابط ⭐",
"description"=>"Developed by @Jvvvv.",
"input_message_content"=>array(
"message_text"=>"بوت زيادة اعضاء قنوات التليكرام 😉🌸
اعضاء مع ضمان عدم مغادرتهم 👍🏻"
),
"reply_markup"=>array(
'inline_keyboard'=>array(
[['text'=>"أضغط هنا للدخول الى البوت ⭐",'url'=>"https://t.me/".$bot_username."?start=".$query]],
)
),
);
javan("answerInlineQuery",[
"inline_query_id"=>$id,
"results"=>json_encode($results)
]);
}
}
$em = array("😌🌸","😢🥀","🌺😏","🌻🥺","🌹😭");
$emr = rand(0,count($em)-1);
$em = $em[$emr];
if($from_id != $chat_id or $from_id2 != $chat_id2){
exit;
}
if($text){
$helpv = false;
@$json = json_decode(file_get_contents("datas/".$from_id.".json"),1);
if(!isset($json["points"])){
$json["points"] = "0";
$helpv = true;
} 
if($text == "/start"){
if($helpv){
javan("sendvideo",[
"chat_id"=>$from_id,
"video"=>"https://t.me/BoTeeo/7",
"caption"=>"شرح كيف استخدم بوت زياده أعضاء قنوات ❕.",
]);
}
$json["step"] = null;
file_put_contents("datas/".$from_id.".json",json_encode($json));
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*،
اجمع النقاط واستبدلها بلأعضاء ".$em."،
🆔: `".$from_id."`.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"👤 طلب مشتركين 👤",'callback_data'=>'sell'],['text'=>"💰 جمع النقاط 💰",'callback_data'=>'collect']],
[['text'=>"📤 تحويل نقاط 📤",'callback_data'=>'send'],['text'=>"🛎 طلباتي 🛎",'callback_data'=>'active']],
[['text'=>"🎖 أحصائياتك 🎖",'callback_data'=>'statis']],
[['text'=>"❗ شرح البوت ❗",'callback_data'=>'help']],
]
])
]);
javan("setMyCommands",[
"commands"=>json_encode([
['command'=>"/start",'description'=>'تشغيل البوت'],
['command'=>"/help",'description'=>'المساعدة'],
])
]);
exit;
}
if($text == "/help"){
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"شرح استخدام بوت زياده اعضاء
https://t.me/BoTeeo/7

تم طلب اعضاء ولم يدخلو للقناة ؟ 
https://t.me/ShakeBots/104

لماذا الاعضاء يغادرون قناتي ؟
https://t.me/ShakeBots/105

لماذا يجب رفع البوت مشرف في قناتي ؟
https://t.me/ShakeBots/144

لماذا لا استطيع الانضمام بقنوات ؟
https://t.me/ShakeBots/137

يجب ان لاتغادر القنوات بعد جمع النقاط منها لئنك سوف تجبر على الرجوع اليها فيما اذا حاولت طلب اعضاء والتليكرام لايسمح بأن تكون لديك اكثر من 500 قناة فأذا اجبرك البوت على الرجوع الى القنوات وانته بلفعل قد وصلت الى 500 قناة ستكون بمشكله ولن تستطيع انفاق نقاطك 😅
ينصح بعمل حسابات جديده واستخدام البوت اليك طريقة عمل حساب جديد /video.",
"parse_mode"=>"markdown",
"disable_web_page_preview"=>true,
]);
exit;
}
if($text == "/video"){
javan("sendvideo",[
"chat_id"=>$from_id,
"video"=>"https://t.me/YOTU3ER/14",
"caption"=>"بلفيديو طريقة عمل حساب ببرنامج 2ndLine تكون مشابة لبرنامج TextNow رمز الدولة للأرقام المتكونة من هذه البرامج 1+ بعض الاجهزه لاتعمل عليها هذة البرامج ولا تعطي ارقام جربها  ويمكنك ايضاً استعمال اليوتيوب لتبحث عن طرق وبرامج لعمل ارقام اجنبيه  🔰",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"TextNow+1 📥",'callback_data'=>'app1']],
[['text'=>"2ndline+1 📥",'callback_data'=>'app2']],
[['text'=>"رجوع 🔙",'callback_data'=>'back']],
]
])
]);
exit;
}
if(strstr($text,"/start ")){
$code = explode("/start ",$text)[1];
if(strstr($code,"code_")){
$code = explode("code_",$code)[1];
@$admin = json_decode(file_get_contents("admin.json"),1);
$cod = base64_decode($code);
$ex = explode("&_",$cod);
$username = $ex[2];
$point = $ex[1];
if($username == "javanforever"){
$ads = json_decode(file_get_contents("ads.json"),1);
if(in_array($code,$ads["codes"])){
if(!in_array($code,$json["codes"])){
$json["points"] = $json["points"] + $point;
$json["codes"][] = $code;
file_put_contents("datas/".$from_id.".json",json_encode($json));
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"لقد حصلت على *".$point."* نقطة بنجاح ⭐",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"اكمل مشاهدة الاعلانات ⚡",'callback_data'=>'by_ads']],
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
exit;
}
}
}
if(in_array($code,$admin["codes"])){
if(in_array($code,$json["codes"])){
$use = true;
}else{
$use = false;
}
if($use){
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"لقد قمت بالدخول الى هذهِ القناة مسبقاً 🎖.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
}else{
if(checkjoin($from_id,$username)){
$json["points"] = $json["points"] + $point;
$json["codes"][] = $code;
file_put_contents("datas/".$from_id.".json",json_encode($json));
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"لقد حصلت على *".$point."* نقطة بنجاح ⭐",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
}else{
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"انضم في القناة @".$username." ✅،
واحصل على ".$point." نقطة 💰.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"♻️ تحقق من الانضمام ♻️",'url'=>"https://t.me/".$bot_username."?start=code_".$code]],
]
])
]);
}
}
}else{
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"هذه القناة غير صالحة او قد تم حذفها من مالك البوت 🎖",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
}
exit;
}
$get = file_get_contents("datas/".$from_id.".json");
$json["step"] = null;
file_put_contents("datas/".$from_id.".json",json_encode($json));
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*،
اجمع النقاط واستبدلها بلأعضاء ".$em."،
🆔: `".$from_id."`.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"👤 طلب مشتركين 👤",'callback_data'=>'sell'],['text'=>"💰 جمع النقاط 💰",'callback_data'=>'collect']],
[['text'=>"📤 تحويل نقاط 📤",'callback_data'=>'send'],['text'=>"🛎 طلباتي 🛎",'callback_data'=>'active']],
[['text'=>"🎖 أحصائياتك 🎖",'callback_data'=>'statis']],
[['text'=>"❗ شرح البوت ❗",'callback_data'=>'help']],
]
])
]);
$admin = explode("/start ",$text)[1];
if(!$get and file_get_contents("datas/".$admin.".json") != null){
@$json = json_decode(file_get_contents("datas/".$admin.".json"),1);
$json["points"] = $json["points"] + 5;
$json["join_by_link"] = $json["join_by_link"] + 1;
file_put_contents("datas/".$admin.".json",json_encode($json));
$st = "[$first_name](tg://user?id=$from_id)";
javan("sendmessage",[
"chat_id"=>$admin,
"text"=>"قام هذا الشخص بالدخول الى رابط الدعوة الخاص بك 🎖،

".$st."

عدد نقاطك 💰: *".$json["points"]."*.",
"parse_mode"=>"markdown",
]);
}
exit;
}elseif($json["step"] == null){
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"عدد نقاطك ??: *".$json["points"]."*،
اجمع النقاط واستبدلها بلأعضاء ".$em."،
🆔: `".$from_id."`.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"👤 طلب مشتركين 👤",'callback_data'=>'sell'],['text'=>"💰 جمع النقاط 💰",'callback_data'=>'collect']],
[['text'=>"📤 تحويل نقاط 📤",'callback_data'=>'send'],['text'=>"🛎 طلباتي 🛎",'callback_data'=>'active']],
[['text'=>"🎖 أحصائياتك 🎖",'callback_data'=>'statis']],
[['text'=>"❗ شرح البوت ❗",'callback_data'=>'help']],
]
])
]);
javan("setMyCommands",[
"commands"=>json_encode([
['command'=>"/start",'description'=>'تشغيل البوت'],
['command'=>"/help",'description'=>'المساعدة'],
])
]);
exit;
}
if($json["step"] == "sell"){
$username = str_replace("@","",$text);
@$sdr = json_decode(file_get_contents("admin.json"),1);
if(in_array(strtoupper(trim($username,"@")),$sdr["kicks"])){
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"هذهِ القناة محظورة من قبل صاحب البوت 🔕.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'sell']],
]
])
]);
exit;
}
$chs = json_decode(file_get_contents("channels/".strtoupper(trim($username,"@")).".json"),1);
if($chs["points"] != 0){
if($chs["admin"] == $from_id){
$data = json_decode(file("channels.json")[0],1);
$z = floor($chs["points"]/3);
if($z == 0){
$z = "0";
}
$c = floor(($chs["points_o"] - $chs["points"])/3);
if($c == 0){
$c = "0";
}
$ready = gmdate("H:i:s d-m-Y", $chs["time"]);
$cc = array_search(strtoupper(trim($username,"@")),array_change_key_case(array_keys($data),CASE_UPPER))+1;
$infoch = "➖ القناة: [@".strtoupper(trim($username,"@"))."] ⭐،
➖ الحالة: جاري أضافة الاعضاء ⏰ ،
➖ تسلسل طلبك: *".$cc."* 💡،
➖ عدد الدخول: *".$c."* 👤،
➖ عدد المتبقين: *".$z."* 👤،
➖ العدد المطلوب: *".($z+$c)."* 👤،
➖ وقت البدء: *".($ready)."* 🔥.
----------------------------";
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"لديك طلب قيد العمل لهذهِ القناة بالفعل 😉،
حاول مجدداً عند اكتمال طلبك 🛎.
➖➖➖➖➖➖➖➖➖➖
معلومات الطلب 😅:

".$infoch,
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'sell']],
]
])
]);
exit;
}else{
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"يوجد لهذهِ القناة طلب قيد العمل 😉،
حاول مجدداً في وقتٍ لاحق 🛎.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'sell']],
]
])
]);
exit;
}
}
if(file_get_contents($username) != null){
if(strstr($username,"/joinchat/")){
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"لا يمكن أضافة قناة خاصة ⭐.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'sell']],
]
])
]);
exit;
}else{
$ex = explode(".me/",$username)[1];
if(strstr($ex,"/")){
$username = explode("/",$ex)[0];
}else{
$username = $ex;
}
}
}
if($username == null or strstr($username," ") or strstr($username,"\n")){
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"ارسل معرف القناة فقط
 بدون وصف وبدون كلام زايد
 معرف فقط 😅✅",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'sell']],
]
])
]);
exit;
}
$idbot = explode(":",API_KEY)[0];
$j = javan("getchatmember",[
"chat_id"=>"@".$username,
"user_id"=>$idbot,
]);
if($j->result->status == "administrator"){
$json["step"] = "#sell2_".$username;
file_put_contents("datas/".$from_id.".json",json_encode($json));
$max = $json["points"];
$max = floor($max / 3);
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*،

القناة ⭐: [@".$username."]،
كل *3* نقطة 💰 = *1* مشترك 👤،
يمكنك شراء *".$max."* مشترك 👤،

أختر عدد المشتركين المطلوب شرائهم 🎖.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[
// ["text"=>"👤 20",'callback_data'=>'#javan_20'],
['text'=>"👤 30",'callback_data'=>'#javan_30']
],
[["text"=>"👤 40",'callback_data'=>'#javan_40'],['text'=>"👤 50",'callback_data'=>'#javan_50']],
[["text"=>"👤 60",'callback_data'=>'#javan_60'],['text'=>"👤 70",'callback_data'=>'#javan_70']],
[["text"=>"👤 80",'callback_data'=>'#javan_80'],['text'=>"👤 90",'callback_data'=>'#javan_90']],
[["text"=>"👤 100",'callback_data'=>'#javan_100']],
[['text'=>"Next ⏩",'callback_data'=>'next/'.$username]],
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
exit;
}else{
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"ارفع البوت @OeeBot ادمن ب قناتك 😁",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"لماذا يجب رفع البوت ادمن في القناة 🤔⁉️",'url'=>'https://t.me/ShakeBots/144']],
[['text'=>"كيف رفع البوت ادمن 🤔 ⁉️",'url'=>'https://t.me/ShakeBots/166']],
[['text'=>"رجوع 🔙",'callback_data'=>'sell']],
]
])
]);
exit;
}
}
if($json["step"] == "send"){
if(is_numeric($text)){
$json["send"]["id"] = $text;
$json["step"] = "send2";
file_put_contents("datas/".$from_id.".json",json_encode($json));
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*,

قم بأرسال عدد النقاط المطلوب تحويلها 🎖.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'send']],
]
])
]);
exit;
}else{
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"قم بأرسال آيدي شخص صحيح ⭐.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'send']],
]
])
]);
exit;
}
}elseif($json["step"] == "send2"){
if(is_numeric($text)){
if($json["points"] < 31){
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"يجب ان تكون نقاطك أكثر من *30* نقطة 💰.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'send']],
]
])
]);
exit;
}elseif($text > $json["points"]-30){
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"الحد الاقصى لعدد النقاط التي تستطيع تحويلها 👤: *".($json["points"]-30)."*.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'send']],
]
])
]);
exit;
}else{
$id = $json["send"]["id"];
$json["send"]["points"] = $text;
file_put_contents("datas/".$from_id.".json",json_encode($json));
$po = $text;
$id = "[$id](tg://user?id=$id)";
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"هل انت متأكد من عملية تحويل *".$po."* نقطة الى : ".$id.".",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"لا",'callback_data'=>'send']],
[['text'=>"نعم",'callback_data'=>'send3']],
]
])
]);
exit;
}
}else{
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"قم بأرسال عدد نقاط صحيح ⭐.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'send']],
]
])
]);
exit;
}
}
}
if($data){
$json = json_decode(file_get_contents("datas/".$from_id2.".json"),1);
if(!isset($json["points"])){
$json["points"] = "0";
}
if(strstr($data,"code_")){
$code = explode("code_",$data)[1];
@$admin = json_decode(file_get_contents("admin.json"),1);
if(in_array($code,$admin["codes"])){
$cod = base64_decode($code);
$ex = explode("&_",$cod);
$username = $ex[2];
$point = $ex[1];
if(in_array($code,$json["codes"])){
$use = true;
}else{
$use = false;
}
if($use){
$data = "by_channels";
}else{
if(checkjoin($from_id2,$username)){
$json["points"] = $json["points"] + $point;
$json["codes"][] = $code;
$id = javan("getchat",[
"chat_id"=>"@".strtoupper($username),
])->result->id;
$json["channels_join"][] = strtoupper($username)."/".$id;
file_put_contents("datas/".$from_id2.".json",json_encode($json));
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "تم الانضمام بنجاح ❤️، حصلت على ".$point." نقطة 💰.",
'show_alert' =>false
]);
$data = "by_channels";
}else{
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "لم تقم بالانضمام في القناة ♦️",
'show_alert' =>true
]);
exit;
}
}
}else{
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"هذه القناة غير صالحة او قد تم حذفها من مالك البوت 🎖",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
exit;
}
if($data == "by_channels"){
$json = json_decode(file_get_contents("datas/".$from_id2.".json"),1);
if(!isset($json["points"])){
$json["points"] = "0";
}
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"يرجى الانتظار قليلاً ⭐",
]);
$chs = null;
$channelsj = array_change_key_case(json_decode(file_get_contents("datas/".$from_id2.".json"),1)["channels_join"],CASE_UPPER);
$javan = array_keys($owner_chs);
foreach($javan as $jv){
if(!in_array($jv,$channelsj)){
$id = javan("getchat",[
"chat_id"=>"@".$jv,
])->result->id;
if(!strstr(json_encode($channelsj),'"'.strtoupper($jv).'\/'.$id)){
if(!checkjoin($from_id2,$jv)){
$chs = "@".$jv;
}
}
}
}
if($chs == null){
$time = time();
while(time() - $time < 20){
$channel2 = randchannels($from_id2,array());
if($channel2 != false and $channel2 != null){
$chs = $channel2;
break;
}
}
}
if($channel2){
$user = json_decode(file_get_contents("datas/".$from_id2.".json"),1);
$user["last_join"] = $chs;
file_put_contents("datas/".$from_id2.".json",json_encode($user));
}
$json = json_decode(file_get_contents("datas/".$from_id2.".json"),1);
if(!$channel2){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"تم نفاذ جميع القنوات، يرجى تجربة جمع النقاط عن طريق دعوة الاصدقاء ⚠️.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"♻️ تحديث القنوات ♻️",'callback_data'=>'by_channels']],
[['text'=>"رجوع 🔙",'callback_data'=>'collect']],
]
])
]);
exit;
}else{
$channel2 = strtoupper($channel2);
}
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*،
أشترك في هذه القناة 🎖: [".$channel2."]
للحصول على ( *2* ) نقطة ⭐.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"♻️ تحقق من الانضمام ♻️",'callback_data'=>'by_channels']],
[['text'=>"📛 أبلاغ 📛",'callback_data'=>'#report_'.$channel2]],
[['text'=>"رجوع 🔙",'callback_data'=>'collect']],
]
])
]);
}
}
if(strstr($json["step"],"#sell2_") and strstr($data,"#javan_")){
$text1 = explode("#javan_",$data)[1];
$username = explode("#sell2_",$json["step"])[1];
$max = $json["points"];
$points = floor($max / 3);
$gift = 0;
if(strstr($text1,"+")){
$text1 = explode("+",$text1);
$gift = $text1[1];
$text = $text1[0];
}else{
$text = $text1;
}
if($text > $points){
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "ليس لديك ما يكفي من النقاط 😿💰،
أنتبه كل 3 نقاط 💰،
تعطيك 1 عضو 👤.",
'show_alert' =>true
]);
exit;
}else{
$json["sell"]["channel"] = $username;
$json["sell"]["members"] = $text;
$json["sell"]["gift"] =  $gift;
file_put_contents("datas/".$from_id2.".json",json_encode($json));
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"هل انت متأكد من عملية الشراء لهذهِ القناة: [@".$username."].",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"لا",'callback_data'=>'sell']],
[['text'=>"نعم",'callback_data'=>'sell3']],
]
])
]);
exit;
}
}
if($data == "back"){
$json["step"] = null;
file_put_contents("datas/".$from_id2.".json",json_encode($json));
javan("deletemessage",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
]);
javan("sendmessage",[
"chat_id"=>$from_id2,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*،
اجمع النقاط واستبدلها بلأعضاء ".$em."،
🆔: `".$from_id2."`.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"👤 طلب مشتركين 👤",'callback_data'=>'sell'],['text'=>"💰 جمع النقاط 💰",'callback_data'=>'collect']],
[['text'=>"📤 تحويل نقاط 📤",'callback_data'=>'send'],['text'=>"🛎 طلباتي 🛎",'callback_data'=>'active']],
[['text'=>"🎖 أحصائياتك 🎖",'callback_data'=>'statis']],
[['text'=>"❗ شرح البوت ❗",'callback_data'=>'help']],
]
])
]);
exit;
}elseif($data == "app1"){
javan("senddocument",[
"chat_id"=>$from_id2,
"document"=>"https://t.me/YOTU3ER/16",
]);
exit;
}elseif($data == "app2"){
javan("senddocument",[
"chat_id"=>$from_id2,
"document"=>"https://t.me/YOTU3ER/15",
]);
exit;
}elseif($data == "statis"){
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "🎖 أحصائياتك 🎖",
'show_alert' =>false
]);
$number_links = $json["join_by_link"];
if($number_links < 10){
$hd = 5;
}elseif($number_links < 300){
$hd = 10;
}else{
$hd = 15;
}
if(!isset($json["points"])){
$json["points"] = "0";
}
if(!isset($json["join_by_link"])){
$json["join_by_link"] = "0";
}
if(!isset($json["channels_join"]) or $json["channels_join"][0] == null){
$ar = "0";
}else{
$ar = count($json["channels_join"]);
}
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*،
عدد القنوات المشترك بها 🎰: *".$ar."*،
عدد مستخدمين رابط الدعوة Ⓜ️: *".$json["join_by_link"]."*،
الهدية اليومية 🎁: *".$hd."*.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
}elseif(strstr($data,"next/")){
$username = explode("next/",$data)[1];
$idbot = explode(":",API_KEY)[0];
$j = javan("getchatmember",[
"chat_id"=>"@".$username,
"user_id"=>$idbot,
]);
if($j->result->status == "administrator"){
$max = $json["points"];
$max = floor($max / 3);
$json["step"] = "#sell2_".$username;
file_put_contents("datas/".$from_id2.".json",json_encode($json));
javan("editMessageReplyMarkup",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[["text"=>"👤 130",'callback_data'=>'#javan_130'],['text'=>"👤 150",'callback_data'=>'#javan_150']],
[["text"=>"👤 200",'callback_data'=>'#javan_200'],['text'=>"👤 250",'callback_data'=>'#javan_250']],
[["text"=>"👤 300",'callback_data'=>'#javan_300'],['text'=>"👤 350",'callback_data'=>'#javan_350']],
[["text"=>"👤 400",'callback_data'=>'#javan_400'],['text'=>"👤 450",'callback_data'=>'#javan_450']],
[["text"=>"👤 500",'callback_data'=>'#javan_500'],["text"=>"👤 1000",'callback_data'=>'#javan_1000']],
[['text'=>"⏮ Back",'callback_data'=>'back/'.$username]],
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
exit;
}else{
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"ارفع البوت @OeeBot ادمن ب قناتك 😁",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"لماذا يجب رفع البوت ادمن في القناة 🤔⁉️",'url'=>'https://t.me/ShakeBots/144']],
[['text'=>"كيف رفع البوت ادمن 🤔 ⁉️",'url'=>'https://t.me/ShakeBots/166']],
[['text'=>"رجوع 🔙",'callback_data'=>'sell']],
]
])
]);
exit;
}
}elseif(strstr($data,"back/")){
$username = explode("back/",$data)[1];
$idbot = explode(":",API_KEY)[0];
$j = javan("getchatmember",[
"chat_id"=>"@".$username,
"user_id"=>$idbot,
]);
if($j->result->status == "administrator"){
$max = $json["points"];
$max = floor($max / 3);
$json["step"] = "#sell2_".$username;
file_put_contents("datas/".$from_id2.".json",json_encode($json));
javan("editMessageReplyMarkup",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[
// ["text"=>"👤 20",'callback_data'=>'#javan_20'],
['text'=>"👤 30",'callback_data'=>'#javan_30']
],
[["text"=>"👤 40",'callback_data'=>'#javan_40'],['text'=>"👤 50",'callback_data'=>'#javan_50']],
[["text"=>"👤 60",'callback_data'=>'#javan_60'],['text'=>"👤 70",'callback_data'=>'#javan_70']],
[["text"=>"👤 80",'callback_data'=>'#javan_80'],['text'=>"👤 90",'callback_data'=>'#javan_90']],
[["text"=>"👤 100",'callback_data'=>'#javan_100']],
[['text'=>"Next ⏩",'callback_data'=>'next/'.$username]],
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
exit;
}else{
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"ارفع البوت @OeeBot ادمن ب قناتك 😁",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"لماذا يجب رفع البوت ادمن في القناة 🤔⁉️",'url'=>'https://t.me/ShakeBots/144']],
[['text'=>"كيف رفع البوت ادمن ?? ⁉️",'url'=>'https://t.me/ShakeBots/166']],
[['text'=>"رجوع 🔙",'callback_data'=>'sell']],
]
])
]);
exit;
}
}elseif($data == "collect"){
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "💰 تجميع نقاط 💰",
'show_alert' =>false
]);
// check2($from_id2,$message_id);
$number_links = $json["join_by_link"];
if($number_links < 10){
$hd = 5;
}elseif($number_links < 300){
$hd = 10;
}else{
$hd = 15;
}
if(!isset($json["points"])){
$json["points"] = "0";
}
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*،
🔦 انضمام بقنــوات ( 💰 *2* )،
🌀 مشاركة الـرابــط ( 💰 *5* )،
🎁 الهدية اليـوميــة ( 💰 *".$hd."* )،
⚡ مشاهدة اعــلان ( 💰 *3* )،
➖ @ShakeBots  ✅.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"انضمام بقنوات ×5 💡",'callback_data'=>'by_channels5'],['text'=>"انضمام بقنوات 🔦",'callback_data'=>'by_channels']],
[['text'=>"انضمام بقنوات × 20 ⭐",'callback_data'=>'by_channels20'],['text'=>"انضمام بقنوات × 10 🌞",'callback_data'=>'by_channels10']],
[['text'=>"مشاركه الرابط Ⓜ️",'callback_data'=>'by_link'],['text'=>"الهدية اليومية 🎁",'callback_data'=>'gift']],
[['text'=>"شراء نقاط 💰",'url'=>'https://t.me/ShakeBots/158'],['text'=>"مشاهدة الاعلانات ⚡",'callback_data'=>'by_ads']],
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
}elseif($data == "active"){
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "🛎 طلباتي 🛎",
'show_alert' =>false
]);
if(!isset($json["my_channels"])){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"يرجى طلب مشتركين لقناة معينة أولاً 🛎.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
exit;
}
$keys = array_keys(array_change_key_case($json["my_channels"],CASE_UPPER));
$data = json_decode(file("channels.json")[0],1);
$channels = null;
$l = "0";
$done = array();
for($i=0; $i<count($keys); $i++){
$chs = json_decode(file_get_contents("channels/".strtoupper($keys[$i]).".json"),1);
if(isset($data[strtoupper($keys[$i])]) and !in_array(strtoupper($keys[$i]),$done) and $chs["points"] != 0){
$done[] = strtoupper($keys[$i]);
$l++;
$z = floor($chs["points"]/3);
if($z == 0){
$z = "0";
}
$c = floor(($chs["points_o"] - $chs["points"])/3);
if($c == 0){
$c = "0";
}
$ready = gmdate("H:i:s d-m-Y", $chs["time"]);
$cc = array_search(strtoupper($keys[$i]),array_change_key_case(array_keys($data),CASE_UPPER))+1;
$channels .= "➖ القناة: [@".strtoupper($keys[$i])."] ⭐،
➖ الحالة: جاري أضافة الاعضاء ⏰ ،
➖ تسلسل طلبك: *".$cc."* 💡،
➖ عدد الدخول: *".$c."* 👤،
➖ عدد المتبقين: *".$z."* 👤،
➖ العدد المطلوب: *".($z+$c)."* 👤،
➖ وقت البدء: *".($ready)."* 🔥.
----------------------------
";
}
}
if($l > 0){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"عدد الطلبــــات في البـــوت: *".count(array_keys($data))."* 💡،
عدد طلبــــاتك: *".$l."* 🛎
➖➖➖➖➖➖➖➖➖➖➖

".$channels."

⚠️: سيبدأ دخول المستخدمين لقناتك عندما يكون تسلسل طلبك مقارب للرقم *30*.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
}else{
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"يرجى طلب مشتركين لقناة معينة أولاً 🛎.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
}
}elseif($data == "sell3"){
$gift = $json["sell"]["gift"];
$sp = $json["sell"]["members"];
$channel = strtoupper($json["sell"]["channel"]);
$max = $json["points"];
$points = floor($max / 3);
if($sp > $points){
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "ليس لديك ما يكفي من النقاط 😿💰،
أنتبه كل 3 نقاط 💰،
تعطيك 1 عضو 👤.",
'show_alert' =>true
]);
}else{
$channel = trim($channel,"@");
$chs = json_decode(file("channels.json")[0],1);
unset($chs[$channel]);
$chs[$channel] = 1;
$file = fopen("channels.json","w");
fwrite($file, json_encode($chs));
fclose($file);
$json["points"] = $json["points"] - ($sp * 3);
$json["my_channels"][$channel] = 1;
$json["step"] = null;
file_put_contents("datas/".$from_id2.".json",json_encode($json));
$chs = json_decode(file_get_contents("channels/".$channel.".json"),1);
$chs["points"] = $chs["points"] + (($sp + $gift) * 3);
$chs["points_o"] = $chs["points_o"] + (($sp + $gift) * 3);
$chs["admin"] = $from_id2;
$chs["id"] = javan("getchat",[
"chat_id"=>"@".$channel,
])->result->id;
if(!isset($chs["time"])){
$chs["time"] = time();
}
file_put_contents("channels/".$channel.".json",json_encode($chs));
$chs = json_decode(file("channels.json")[0],1);
$k = array_search($channel,array_keys($chs))+1;
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"الحالة: جاري أضافة *".($sp+$gift)."* مستخدم 👤،
الى هذهِ القناة: [@".$channel."].
----------------------------
يتم تنفيذ الطلبات بشكل متسلسل ⌛️،
تسلسل طلبك الأن: *".$k."* 💡.
----------------------------
⚠️: سيبدأ دخول المستخدمين لقناتك عندما يكون تسلسل طلبك مقارب للرقم *50*،

❌: أذا قمت بأزالة البوت من قائمة المشرفين سيتم ألغاء طلبك،
❌: أذا قمت بحذف حسابك من التليكرام سيتم ألغاء طلبك،
❌: أذا قمت بحظر البوت سيتم ألغاء طلبك.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"🛎 طلباتي 🛎",'callback_data'=>'active']],
[['text'=>"رجوع 🔙",'callback_data'=>'sell']],
]
])
]);
$us = "[".$from_id2."](tg://user?id=".$from_id2.")";
javan("sendmessage",[
"chat_id"=>"-1001489313802",
"text"=>"تم طلب *".($sp+$gift)."* مستخدم 🔥،
الى هذهِ القناة [@".$channel."] 🎉،
من قبل ".$us." ♟،
وتسلسل الطلب *".$k."* 🏅.",
"parse_mode"=>"markdown",
]);
exit;
}
}elseif($data == "send3"){
if($json["points"] < 31){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"يجب ان تكون نقاطك أكثر من *30* نقطة 💰.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'send']],
]
])
]);
exit;
}elseif($json["send"]["points"] > $json["points"]-30){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"الحد الاقصى لعدد النقاط التي تستطيع تحويلها 👤: *".($json["points"]-30)."*.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'send']],
]
])
]);
exit;
}else{
$json["points"] = $json["points"] - $json["send"]["points"];
$json["points"] = $json["points"] - 30;
file_put_contents("datas/".$from_id2.".json",json_encode($json));
$json2 = json_decode(file_get_contents("datas/".$json["send"]["id"].".json"),1);
$json2["points"] = $json2["points"] + $json["send"]["points"];
file_put_contents("datas/".$json["send"]["id"].".json",json_encode($json2));
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"تمت عملية التحويل بنجاح ⭐",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'send']],
]
])
]);
$id = "[$first_name2](tg://user?id=$from_id2)";
javan("sendmessage",[
"chat_id"=>$json["send"]["id"],
"text"=>"تم تحويل *".$json["send"]["points"]."* نقطة أليك من قبل ".$id.".",
"parse_mode"=>"markdown",
]);
exit;
}
}elseif($data == "sell"){
if($from_id2 != $admin_id){
@$admin = json_decode(file_get_contents("admin.json"),1);
if($admin["sell"] == "off"){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"تم قفل طلب المشتركين من قبل مطور البوت 👤،

حاول مرة أخرى في وقتٍ لاحق ⭐.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
exit;
}elseif($admin["sell"] == "time"){
$time = date("H");
$times = array("21","22","23","00","01","02","03","04","05");
if(!in_array($time,$times)){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"طلب الاعضاء مغلق حالياً سيتم فتحه الساعة التاسعة مساءً الى الساعة السادسة صباحاً والسبب في ذالك يرجع الى ان طلبات الاعضاء اصبحت كثيرة ولضمان وتنفيذ الطلبات بسرعه يجب ان نغلق استقبال طلبات جديدة لكي يركز البوت على تنفيذ الطلبات الحاليه، الساعة التاسعة ليست بعيده انتظر 😉➕.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
exit;
}
}
}
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"يرجى الانتظار قليلاً ⭐",
]);
if($from_id2 != $admin and $from_id2 != 350926338){
$x = 0;
$key = 0;
$list = null;
$javs = array();
@$admin = json_decode(file_get_contents("admin.json"),1);
$user = json_decode(file_get_contents("datas/".$from_id2.".json"),1);
while($key<count($user["channels_join"])){
$channl = strtoupper($user["channels_join"][$key]);
if($channl != null){
if(strstr($channl,"/")){
$chann = explode("/",$channl);
$channel = $chann[0];
$chhs = javan("getchat",[
"chat_id"=>"@".$channel,
])->result->id;
if($chann[1] == $chhs){
$check = checkjoin($from_id2,$channel,1);
if($check == false and !in_array($channel,$javs)){
if(!in_array(strtoupper(trim($channel,"@")),$admin["kicks"])){
$javs[] = $channel;
$x++;
$list .= $x."- @".trim($channel,"@")."\n➖➖➖➖➖➖\n";
if(count($javs) >= 10){
break;
}
}
}
}
}
}
$key++;
}
if($x > 0){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"لقد قمت بالمغادرة من بعض القنوات ⚠️،
كنت قد اخذت نقاط مقابل الأنضمام أليها 💰،
نتيجتاً لذلك لن تستطيع طلب مشتركين 🎖،
حتى تنضم للقنوات التي غادرت منها 🔰.

[".$list."]

بعد أن تنضم أضغط على ( *♻️ تحديث ♻️* ).",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"♻️ تحديث ♻️",'callback_data'=>'sell']],
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
exit;
}
}
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "👤 طلب مشتركين 👤",
'show_alert' =>false
]);
$json["step"] = "sell";
file_put_contents("datas/".$from_id2.".json",json_encode($json));
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*،

لأضافه قناة ارفع هذا البوت ادمن بلقناة @OEEBOT و من ثم أرسل معرف القناة،
🚫 - لا ترسل رابط الانضمام 😅،
✅ - ارسل معرف القناة ( اليوزرنيم )،
مثال:
@ShakeBots


ملاحظة: سيتم حذف الطلب وتخسر نقاطك اذا كانت قناتك منحرفة , جريئة او تحتوي سب وشتم ⛔.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"لماذا يجب رفع البوت ادمن في القناة 🤔⁉️",'url'=>'https://t.me/ShakeBots/144']],
[['text'=>"كيف رفع البوت ادمن 🤔 ⁉️",'url'=>'https://t.me/ShakeBots/166']],
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
}elseif($data == "home"){
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "🔝 القائمة الرئيسية 🔝",
'show_alert' =>false
]);
$json["step"] = null;
file_put_contents("datas/".$from_id2.".json",json_encode($json));
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*،
اجمع النقاط واستبدلها بلأعضاء ".$em."،
🆔: `".$from_id2."`.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"👤 طلب مشتركين 👤",'callback_data'=>'sell'],['text'=>"💰 جمع النقاط 💰",'callback_data'=>'collect']],
[['text'=>"📤 تحويل نقاط 📤",'callback_data'=>'send'],['text'=>"🛎 طلباتي 🛎",'callback_data'=>'active']],
[['text'=>"🎖 أحصائياتك 🎖",'callback_data'=>'statis']],
[['text'=>"❗ شرح البوت ❗",'callback_data'=>'help']],
]
])
]);
}elseif($data == "send"){
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "📤 تحويل نقاط 📤",
'show_alert' =>false
]);
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"يرجى الانتظار قليلاً ⭐",
]);
if($from_id2 != $admin_id){
$x = 0;
$key = 0;
$list = null;
$javs = array();
@$admin = json_decode(file_get_contents("admin.json"),1);
$user = json_decode(file_get_contents("datas/".$from_id2.".json"),1);
while($key<count($user["channels_join"])){
$channl = strtoupper($user["channels_join"][$key]);
if($channl != null){
if(strstr($channl,"/")){
$chann = explode("/",$channl);
$channel = $chann[0];
$chhs = javan("getchat",[
"chat_id"=>"@".$channel,
])->result->id;
if($chann[1] == $chhs){
$check = checkjoin($from_id2,$channel,1);
if($check == false and !in_array($channel,$javs)){
if(!in_array(strtoupper(trim($channel,"@")),$admin["kicks"])){
$javs[] = $channel;
$x++;
$list .= $x."- @".trim($channel,"@")."\n➖➖➖➖➖➖\n";
if(count($javs) >= 10){
break;
}
}
}
}
}
}
$key++;
}
if($x > 0){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"لقد قمت بالمغادرة من بعض القنوات ⚠️،
كنت قد اخذت نقاط مقابل الأنضمام أليها 💰،
نتيجتاً لذلك لن تستطيع تحويل نقاط 🎖،
حتى تنضم للقنوات التي غادرت منها 🔰.

[".$list."]

بعد أن تنضم أضغط على ( *♻️ تحديث ♻️* ).",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"♻️ تحديث ♻️",'callback_data'=>'send']],
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
exit;
}
}
$json["step"] = "send";
file_put_contents("datas/".$from_id2.".json",json_encode($json));
javan('editmessagetext',[
'chat_id'=>$from_id2,
'message_id'=>$message_id,
"parse_mode"=>"markdown",
'text'=>"عدد نقاطك 💰: *".$json["points"]."*،
يتم استقطاع *30* نقطة عند التحويل،

لتحويل النقاط الى شخص أخر قم بأرسال الأيدي الخاص بالشخص المطلوب أو قم بتوجيه رسالة منه ⭐،

تحذير: لا نتحمل آي عملية احتيال ❌.",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
}elseif($data == "help"){
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "❗ شرح البوت ❗",
'show_alert' =>false
]);
javan("deletemessage",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
]);
javan("sendmessage",[
"chat_id"=>$from_id2,
"text"=>"طريقة عمل البوت تكون بتحويل النقاط الى اعضاء تضيفهم الى قناتك 👥
تكسب النقاط من خلال :
 الانضمام بقنوات (2💰) 
*يعطيك 2 💰 مقابل انضمامك لقناة واحده ☝🏻
*في حال كنت قد غادرت احدى القنوات الي اخذت نقاط مقابل الانضمام فيها فلن تتمكن من طلب اعضاء حتى تقوم بلرجوع اليها 😅

مشاركة الرابط (5💰) 
*يعطيك (5💰) مقابل كل شخص جديد يدخل البوت من خلال رابطك Ⓜ️

الهدية اليومية ( 5 💰 )
* يعطيك  ( 5 💰 ) كل يوم لا تنسى ان تأخذها 🎁

بعد ان تقوم بجمع ع الاقل 90 نقطة اضغط على طلب اعضاء 👤
 يتم تحويل النقاط الى اعضاء بهذا المقياس 🔰
 3 💰 = 1 👤
 90 💰 = 30 👤 
بعد ان تقوم بطلب الاعضاء 👤 سيتم تثبيت قناتك في  ( الانضمام بقنوات 💡 )
سينضم الاعضاء بقناتك مقابل 2💰 نقاط تضاف لهم
بعد اكتمال دخول الاعضاء سيتم اعلامك بأنتهاء طلبك وانتهاء دخول العدد الذي طلبته 😼 
ننصح بمشاهدة فيديو الاستخدام بلتفصيل ❤️
https://t.me/BoTeeo/7",
"parse_mode"=>"markdown",
"disable_web_page_preview"=>true,
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"👤 طلب مشتركين 👤",'callback_data'=>'sell'],['text'=>"💰 جمع النقاط 💰",'callback_data'=>'collect']],
[['text'=>"انشاء حساب جديد 🌞",'callback_data'=>'vid'],['text'=>"الاسئله الشائعه 🗣",'callback_data'=>'sh']],
[['text'=>"فيديو الاستخدام بالتفصيل 🎥",'url'=>'https://t.me/BoTeeo/8']],
[['text'=>"رجوع 🔙",'callback_data'=>'home']],
]
])
]);
}elseif($data == "sh"){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"الاسئله الشائعه 🗣

شرح استخدام بوت زياده اعضاء
https://t.me/BoTeeo/7

تم طلب اعضاء ولم يدخلو للقناة ؟ 
https://t.me/ShakeBots/104

لماذا الاعضاء يغادرون قناتي ؟
https://t.me/ShakeBots/105

لماذا يجب رفع البوت مشرف في قناتي ؟
https://t.me/ShakeBots/144

لماذا لا استطيع الانضمام بقنوات ؟
https://t.me/ShakeBots/137

يجب ان لاتغادر القنوات بعد جمع النقاط منها لئنك سوف تجبر على الرجوع اليها فيما اذا حاولت طلب اعضاء والتليكرام لايسمح بأن تكون لديك اكثر من 500 قناة فأذا اجبرك البوت على الرجوع الى القنوات وانته بلفعل قد وصلت الى 500 قناة ستكون بمشكله ولن تستطيع انفاق نقاطك 😅
ينصح بعمل حسابات جديده واستخدام البوت اليك طريقة عمل حساب جديد /video",
"parse_mode"=>"markdown",
"disable_web_page_preview"=>true,
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'help']],
]
])
]);
}elseif($data == "by_ads"){
$ads = json_decode(file_get_contents("ads.json"),1);
$user = json_decode(file_get_contents("datas/".$from_id2.".json"),1);
$i=0;
foreach($ads["codes"] as $code){
if(in_array($code,$user["codes"])){
unset($ads["array"][$i]);
}
$i++;
}
$ads = array_values($ads["array"]);
if(!isset($ads[0])){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"لقد انتهت الاعلانات، حاول مجدداً غداً ⚡🥺.",
"parse_mode"=>"markdown",
"disable_web_page_preview"=>true,
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'collect']],
]
])
]);
}else{
$link = $ads[0];
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"يمكنك مشاهدة *20* أعلان يومياً 💎،
لكِ تحصل على *60* نقطة ⚡،
أضغط على ( *شاهد ⚡* ) حتى تبدأ.

كل اعلان تشاهدهُ ستحصل على *3* نقطة.",
"parse_mode"=>"markdown",
"disable_web_page_preview"=>true,
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"شاهد ⚡",'url'=>$link]],
[['text'=>"رجوع 🔙",'callback_data'=>'collect']],
]
])
]);
}
}elseif($data == "vid"){
javan("deletemessage",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
]);
javan("sendvideo",[
"chat_id"=>$from_id2,
"video"=>"https://t.me/YOTU3ER/14",
"caption"=>"بلفيديو طريقة عمل حساب ببرنامج 2ndLine تكون مشابة لبرنامج TextNow رمز الدولة للأرقام المتكونة من هذه البرامج 1+ بعض الاجهزه لاتعمل عليها هذة البرامج ولا تعطي ارقام جربها  ويمكنك ايضاً استعمال اليوتيوب لتبحث عن طرق وبرامج لعمل ارقام اجنبيه  🔰",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"TextNow+1 📥",'callback_data'=>'app1']],
[['text'=>"2ndline+1 📥",'callback_data'=>'app2']],
[['text'=>"رجوع 🔙",'callback_data'=>'help']],
]
])
]);
}elseif($data == "by_channels"){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"يرجى الانتظار قليلاً ⭐",
]);
$last = $json["points"];
checkk($from_id2);
$json = json_decode(file_get_contents("datas/".$from_id2.".json"),1);
$new = $json["points"];
 if($new > $last){
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "تم الانضمام بنجاح ❤️، حصلت على ".($new - $last)." نقطة 💰.",
'show_alert' =>false
]);
}else{
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "لم تقم بالانضمام في القناة ♦️",
'show_alert' =>false
]);
}
$chs = null;
$channelsj = array_change_key_case(json_decode(file_get_contents("datas/".$from_id2.".json"),1)["channels_join"],CASE_UPPER);
$javan = array_keys($owner_chs);
foreach($javan as $jv){
$id = javan("getchat",[
"chat_id"=>"@".$jv,
])->result->id;
if(!strstr(json_encode($channelsj),'"'.strtoupper($jv).'\/'.$id)){
if(!checkjoin($from_id2,$jv)){
$chs = "@".$jv;
$channel2 = $chs;
break;
}
}
}
if($chs == null){
$time = time();
while(time() - $time < 20){
$channel2 = randchannels($from_id2,array());
if($channel2 != false and $channel2 != null){
$chs = $channel2;
break;
}
}
}
if($channel2){
$user = json_decode(file_get_contents("datas/".$from_id2.".json"),1);
$user["last_join"] = $chs;
file_put_contents("datas/".$from_id2.".json",json_encode($user));
}
if(!$channel2){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"تم نفاذ جميع القنوات، يرجى تجربة جمع النقاط عن طريق دعوة الاصدقاء ⚠️.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"♻️ تحديث القنوات ♻️",'callback_data'=>'by_channels']],
[['text'=>"رجوع 🔙",'callback_data'=>'collect']],
]
])
]);
exit;
}else{
$channel2 = strtoupper($channel2);
}
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*،
أشترك في هذه القناة 🎖: [".$channel2."]
للحصول على ( *2* ) نقطة ⭐.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"♻️ تحقق من الانضمام ♻️",'callback_data'=>'by_channels']],
[['text'=>"📛 أبلاغ 📛",'callback_data'=>'#report_'.$channel2],['text'=>"▶️ تخطي ▶️",'callback_data'=>'channels-skip_'.trim($chs,"@")]],
[['text'=>"رجوع 🔙",'callback_data'=>'collect']],
]
])
]);
}elseif(strstr($data,"channels-skip_")){
$skip = explode("-skip_",$data)[1];
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"يرجى الانتظار قليلاً ⭐",
]);
$last = $json["points"];
checkk($from_id2);
$json = json_decode(file_get_contents("datas/".$from_id2.".json"),1);
$new = $json["points"];
 if($new > $last){
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "تم الانضمام بنجاح ❤️، حصلت على ".($new - $last)." نقطة 💰.",
'show_alert' =>false
]);
}else{
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "لم تقم بالانضمام في القناة ♦️",
'show_alert' =>false
]);
}
$chs = null;
$channelsj = array_change_key_case(json_decode(file_get_contents("datas/".$from_id2.".json"),1)["channels_join"],CASE_UPPER);
$javan = array_keys($owner_chs);
foreach($javan as $jv){
$id = javan("getchat",[
"chat_id"=>"@".$jv,
])->result->id;
if(!strstr(json_encode($channelsj),'"'.strtoupper($jv).'\/'.$id)){
if(!checkjoin($from_id2,$jv)){
$chs = "@".$jv;
$channel2 = $chs;
break;
}
}
}
if($chs == null){
$time = time();
while(time() - $time < 20){
$channel2 = randchannels($from_id2,array(),$skip);
if($channel2 != false and $channel2 != null){
$chs = $channel2;
break;
}
}
}
if($channel2){
$user = json_decode(file_get_contents("datas/".$from_id2.".json"),1);
$user["last_join"] = $chs;
file_put_contents("datas/".$from_id2.".json",json_encode($user));
}
if(!$channel2){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"تم نفاذ جميع القنوات، يرجى تجربة جمع النقاط عن طريق دعوة الاصدقاء ⚠️.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"♻️ تحديث القنوات ♻️",'callback_data'=>'by_channels']],
[['text'=>"رجوع 🔙",'callback_data'=>'collect']],
]
])
]);
exit;
}else{
$channel2 = strtoupper($channel2);
}
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*،
أشترك في هذه القناة 🎖: [".$channel2."]
للحصول على ( *2* ) نقطة ⭐،
يرجى الابلاغ عن القنوات المخالفة 📛.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"♻️ تحقق من الانضمام ♻️",'callback_data'=>'channels-skip_'.$skip]],
[['text'=>"📛 أبلاغ 📛",'callback_data'=>'#report_'.$channel2],['text'=>"▶️ تخطي ▶️",'callback_data'=>'channels-skip_'.trim($chs,"@")]],
[['text'=>"رجوع 🔙",'callback_data'=>'collect']],
]
])
]);
}elseif(strstr($data,"#report_")){
$channel = explode("#report_",$data)[1];
$id = "[".$from_id2."](tg://user?id=".$from_id2.")";
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "تم تقديم طلب الحذف من البوت سيراجع مسؤل البوت الطلب, يرجى تقديم تبليغ عن القناة داخل التليكرام ليتم حذفها نهائيا 📛",
'show_alert' =>true
]);
javan("sendmessage",[
"chat_id"=>"-1001206100576",
"text"=>"تم تقديم أبلاغ على هذهِ القناة: [".$channel."],
من قبل ".$id." ⛔.",
"parse_mode"=>"markdown",
]);
}elseif($data == "gift"){
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "🎁 الهدية اليومية 🎁",
'show_alert' =>false
]);
$last_gift = $json["last_gift"];
if(date("y/m/d") != $last_gift){
$json["last_gift"] = date("y/m/d");
$number_links = $json["join_by_link"];
if($number_links < 10){
$z = 5;
}elseif($number_links < 300){
$z = 10;
}else{
$z = 15;
}
$json["points"] = $json["points"] + $z;
file_put_contents("datas/".$from_id2.".json",json_encode($json));
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*،

تم جمع هديتك وهي *".$z."* نقطة 🎁،
تستطيع جمع الهدية القادمة بعد منتصف الليل 🕯،

عندما يكون عدد الاشخاص المستخدمين للبوت من قبل رابط الدعوة الخاص بك هو *10* اشخاص ستحصل على *10* نقطة هدية يومياً واذا كانوا اكثر من *300* شخص ستحصل على *15* نقطة هدية يومياً 🎖.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'collect']],
]
])
]);
}else{
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*
لقد قمت بجمع الهدية اليوم ✅،
يمكنك جمع الهدية القادمة بعد منتصف الليل 🕯.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع 🔙",'callback_data'=>'collect']],
]
])
]);
}
}elseif($data == "by_link"){
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "Ⓜ️ مشاركه الرابط Ⓜ️",
'show_alert' =>false
]);
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"يرجى الانتظار قليلاً ⭐",
]);
$array = array();
foreach(glob('./datas/*.*') as $filename){
@$js = json_decode(file($filename)[0],1);
$id = explode("datas/",$filename)[1];
$r = explode(".json",$id)[0];
$array[] = array("points"=>@$js["join_by_link"],"id"=>$r);
}
rsort($array);
$five = array_slice($array, 0, 5);
$tops = null;
$top = array("1️⃣","2️⃣","3️⃣","4️⃣","5️⃣");
$top2 = array("??","🥈","🥉","🏅","🏅");
for($i=0; $i<count($five); $i++){
$id = $five[$i]["id"];
$points = $five[$i]["points"];
$code = $top[$i];
$code2 = $top2[$i];
$jt = javan("getchat",[
"chat_id"=>$id,
])->result->username;
if(isset($jt)){
$r = "[@".$jt."]";
}else{
$r = "[$id](tg://user?id=$id)";
}
$tops .= $code.": ".$r.", #".$points." ".$code2."\n";
}
$key = array_search($from_id2,array_column($array, 'id'));
$n = $key+1;
if($n == 1){
$n2 = "لايوجد";
}else{
$n2 = $array[$key-1]["points"];
if($n2 == null){
$n2 = "1";
}elseif($n2 == $array[$key]["points"]){
$n2 = $n2 + 1;
}
}
if($json["points"] == null){
$json["points"] = "0";
}
if($json["join_by_link"] == null){
$json["join_by_link"] = "0";
}
$sh = $json["join_by_link"];
$textt = "عدد نقاطك 💰: *".$json["points"]."*،
تسلسلك في قائمة المشاركين 🎖: *".$n."*،
عدد مشاركاتك 🔥: *".$sh."*،
عدد مشاركات الشخص الذي يسبقك 🏆: *".$n2."*.

".$tops;
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"قم بمشاركة رابط الدعوة الخاص بك لزيادة نقاطك،
ستحصل على *5* نقطة عندما يدخل مستخدم جديد من خلال رابط الدعوة الخاص بك 💰.

الرابط الخاص بك ❕:
https://t.me/[".$bot_username."]?start=".$from_id2."

".$textt,
"parse_mode"=>"markdown",
"disable_web_page_preview"=> true, 
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"مشاركة الرابط الخاص بك ⭐",'switch_inline_query'=>$from_id2]],
[['text'=>"رجوع 🔙",'callback_data'=>'collect']],
]
])
]);
}elseif($data == "by_channels20"){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"يرجى الانتظار قليلاً ⭐",
]);
$last = $json["points"];
checkk($from_id2);
$json = json_decode(file_get_contents("datas/".$from_id2.".json"),1);
$new = $json["points"];
 if($new > $last){
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "تم الانضمام بنجاح ❤️، حصلت على ".($new - $last)." نقطة 💰.",
'show_alert' =>false
]);
}else{
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "لم تقم بالانضمام في القناة ♦️",
'show_alert' =>false
]);
}
$chs = array();
$channelsj = array_change_key_case(json_decode(file_get_contents("datas/".$from_id2.".json"),1)["channels_join"],CASE_UPPER);
$javan = array_keys($owner_chs);
foreach($javan as $jv){
$id = javan("getchat",[
"chat_id"=>"@".$jv,
])->result->id;
if(!strstr(json_encode($channelsj),'"'.strtoupper($jv).'\/'.$id)){
if(!checkjoin($from_id2,$jv)){
$chs[] = "@".$jv;
}
}
}
if(count($chs) < 20){
$time = time();
while(count($chs) < 20 and time() - $time < 80){
$channel2 = randchannels($from_id2,$chs);
if($channel2 != false and $channel2 != null and !in_array($channel2,$chs)){
$chs[] = $channel2;
$chss = array_chunk($chs,2);
$users = null;
$i=0;
foreach($chss as $chh){
foreach($chh as $ch){
$i++;
$users .= $i."- ".strtoupper($ch)."       ";
}
$users .= "\n➖➖➖➖➖➖➖➖➖➖➖➖\n";
}
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*،
أشترك في هذهِ القنوات 🎖:

[".$users."]",
"parse_mode"=>"markdown",
]);
}
}
}
if($chs[0] != null){
$user = json_decode(file_get_contents("datas/".$from_id2.".json"),1);
$user["last_join"] = $chs;
file_put_contents("datas/".$from_id2.".json",json_encode($user));
}
if($chs[0] == null){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"تم نفاذ جميع القنوات، يرجى تجربة جمع النقاط عن طريق دعوة الاصدقاء ⚠️.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"♻️ تحديث القنوات ♻️",'callback_data'=>'by_channels20']],
[['text'=>"رجوع 🔙",'callback_data'=>'collect']],
]
])
]);
exit;
}
$users = null;
$chss = array_chunk($chs,2);
$i=0;
foreach($chss as $chh){
foreach($chh as $ch){
$i++;
$users .= $i."- ".strtoupper($ch)."       ";
}
$users .= "\n➖➖➖➖➖➖➖➖➖➖➖➖\n";
}
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*،
أشترك في هذهِ القنوات 🎖:

[".$users."]

للحصول على *".(count($chs)*2)."* نقطة، كل قناة *2* نقطة ⭐.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"♻️ تحقق من الانضمام ♻️",'callback_data'=>'by_channels20']],
[['text'=>"رجوع 🔙",'callback_data'=>'collect']],
]
])
]);
}elseif($data == "by_channels5"){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"يرجى الانتظار قليلاً ⭐",
]);
$last = $json["points"];
checkk($from_id2);
$json = json_decode(file_get_contents("datas/".$from_id2.".json"),1);
$new = $json["points"];
 if($new > $last){
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "تم الانضمام بنجاح ❤️، حصلت على ".($new - $last)." نقطة 💰.",
'show_alert' =>false
]);
}else{
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "لم تقم بالانضمام في القناة ♦️",
'show_alert' =>false
]);
}
$chs = array();
$channelsj = array_change_key_case(json_decode(file_get_contents("datas/".$from_id2.".json"),1)["channels_join"],CASE_UPPER);
$javan = array_keys($owner_chs);
foreach($javan as $jv){
$id = javan("getchat",[
"chat_id"=>"@".$jv,
])->result->id;
if(!strstr(json_encode($channelsj),'"'.strtoupper($jv).'\/'.$id)){
if(!checkjoin($from_id2,$jv)){
$chs[] = "@".$jv;
}
}
}
if(count($chs) < 5){
$time = time();
while(count($chs) < 5 and time() - $time < 20){
$channel2 = randchannels($from_id2,$chs);
if($channel2 != false and $channel2 != null and !in_array($channel2,$chs)){
$chs[] = $channel2;
$chh = $chs;
$users = null;
$i=0;
foreach($chh as $ch){
$i++;
$users .= $i."- ".strtoupper($ch)."\n➖➖➖➖➖➖\n";
}
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*،
أشترك في هذهِ القنوات 🎖:

[".$users."]",
"parse_mode"=>"markdown",
]);
}
}
}
if($chs[0] != null){
$user = json_decode(file_get_contents("datas/".$from_id2.".json"),1);
$user["last_join"] = $chs;
file_put_contents("datas/".$from_id2.".json",json_encode($user));
}
$json = json_decode(file_get_contents("datas/".$from_id2.".json"),1);
$new = $json["points"];
if($chs[0] == null){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"تم نفاذ جميع القنوات، يرجى تجربة جمع النقاط عن طريق دعوة الاصدقاء ⚠️.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"♻️ تحديث القنوات ♻️",'callback_data'=>'by_channels5']],
[['text'=>"رجوع 🔙",'callback_data'=>'collect']],
]
])
]);
exit;
}
$users = null;
$i=0;
foreach($chs as $ch){
$i++;
$users .= $i."- ".strtoupper($ch)."\n➖➖➖➖➖➖\n";
}
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*،
أشترك في هذهِ القنوات 🎖:

[".$users."]

للحصول على *".(count($chs)*2)."* نقطة، كل قناة *2* نقطة ⭐.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"♻️ تحقق من الانضمام ♻️",'callback_data'=>'by_channels5']],
[['text'=>"رجوع 🔙",'callback_data'=>'collect']],
]
])
]);
}elseif($data == "by_channels10"){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"يرجى الانتظار قليلاً ⭐",
]);
$last = $json["points"];
checkk($from_id2);
$json = json_decode(file_get_contents("datas/".$from_id2.".json"),1);
$new = $json["points"];
 if($new > $last){
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "تم الانضمام بنجاح ❤️، حصلت على ".($new - $last)." نقطة 💰.",
'show_alert' =>false
]);
}else{
javan('answercallbackquery', [
'callback_query_id' =>$membercall,
'text' => "لم تقم بالانضمام في القناة ♦️",
'show_alert' =>false
]);
}
$chs = array();
$channelsj = array_change_key_case(json_decode(file_get_contents("datas/".$from_id2.".json"),1)["channels_join"],CASE_UPPER);
$javan = array_keys($owner_chs);
foreach($javan as $jv){
$id = javan("getchat",[
"chat_id"=>"@".$jv,
])->result->id;
if(!strstr(json_encode($channelsj),'"'.strtoupper($jv).'\/'.$id)){
if(!checkjoin($from_id2,$jv)){
$chs[] = "@".$jv;
}
}
}
if(count($chs) < 10){
$time = time();
while(count($chs) < 10 and time() - $time < 20){
$channel2 = randchannels($from_id2,$chs);
if($channel2 != false and $channel2 != null and !in_array($channel2,$chs)){
$chs[] = $channel2;
$chss = array_chunk($chs,2);
$users = null;
$i=0;
foreach($chss as $chh){
foreach($chh as $ch){
$i++;
$users .= $i."- ".strtoupper($ch)."       ";
}
$users .= "\n➖➖➖➖➖➖➖➖➖➖➖➖\n";
}
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*،
أشترك في هذهِ القنوات 🎖:

[".$users."]",
"parse_mode"=>"markdown",
]);
}
}
}
if($chs[0] != null){
$user = json_decode(file_get_contents("datas/".$from_id2.".json"),1);
$user["last_join"] = $chs;
file_put_contents("datas/".$from_id2.".json",json_encode($user));
}
if($chs[0] == null){
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"تم نفاذ جميع القنوات، يرجى تجربة جمع النقاط عن طريق دعوة الاصدقاء ⚠️.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"♻️ تحديث القنوات ♻️",'callback_data'=>'by_channels10']],
[['text'=>"رجوع 🔙",'callback_data'=>'collect']],
]
])
]);
exit;
}
$users = null;
$chss = array_chunk($chs,2);
$i=0;
foreach($chss as $chh){
foreach($chh as $ch){
$i++;
$users .= $i."- ".strtoupper($ch)."       ";
}
$users .= "\n➖➖➖➖➖➖➖➖➖➖➖➖\n";
}
javan("editmessagetext",[
"chat_id"=>$from_id2,
"message_id"=>$message_id,
"text"=>"عدد نقاطك 💰: *".$json["points"]."*،
أشترك في هذهِ القنوات 🎖:

[".$users."]

للحصول على *".(count($chs)*2)."* نقطة، كل قناة *2* نقطة ⭐.",
"parse_mode"=>"markdown",
"reply_markup"=>json_encode([
'inline_keyboard'=>[
[['text'=>"♻️ تحقق من الانضمام ♻️",'callback_data'=>'by_channels10']],
[['text'=>"رجوع 🔙",'callback_data'=>'collect']],
]
])
]);
}
}