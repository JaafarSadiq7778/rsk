<?php
ini_set('memory_limit', -1);
define('API_KEY',$argv[2]);
function javan($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}
@$admin = json_decode(file_get_contents("admin.json"),1);
$idm = $argv[1];
$users = count(glob('./datas/*.*'))+1;
javan('sendMessage',[ 
'chat_id'=>$idm, 
'text'=>"جاري الأذاعه الى: *".$users."* مستخدم.",
'parse_mode'=> 'markdown', 
]); 
$alluser = 0;
$us = glob('./datas/*.*');
for($i=0; $i<count($us); $i++){
$filename = $us[$i];
$alluser++;
$id = explode("datas/",$filename)[1];
$r = explode(".json",$id)[0];
if (preg_match("/^\d+$/", $r)) {
$jv = javan('forwardMessage',[
 'chat_id'=>$r,
 'from_chat_id'=>$idm,
'message_id'=>$admin["aza3a"],
 ]);
 if(@$jv->error_code == 429){
 $jvv = $jv->parameters->retry_after;
 $i--;
 echo "sleep ".$jvv."\n";
 sleep($jvv);
 }else{
 usleep(250000);
 echo $r."\n";
}
}
}
javan("sendmessage",[
"chat_id"=>$idm,
"text"=>"تم الاذاعه بنجاح الى: ".$alluser." مشترك."
]);
exit;