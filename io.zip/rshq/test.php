<?php
echo file_get_contents("datas/350926338.json");
