<?php
$token = '1149409334:AAHKO8v3xk6KATbQOqpx18_f-doy228hdWA';
function javan($method,$datas=[]){
global $token;
$url = "https://api.telegram.org/bot".$token."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$text = $message->text;
if($text){
javan("sendmessage",[
"chat_id"=>$from_id,
"text"=>"جاري صيانة البوت",
"parse_mode"=>"markdown",
]);
}