<?php
date_default_timezone_set('Asia/Baghdad');
$token = '6067746005:AAHbPROXfSg21c3kftp-LnvjET6RTJYPkv0';
$redis  = new Redis();
$er = false;
try{
$connected = $redis->connect('127.0.0.1', 6379);
if(!$connected){
$er = true;
}
}catch(Exception $e) {
$er = true;
}
if($er){
if(!strstr(shell_exec("sudo redis-cli ping"),"PONG")){
shell_exec('sudo redis-server /etc/redis/redis.conf > /dev/null 2>/dev/null &');
sleep(1);
try{
$connected = $redis->connect('127.0.0.1', 6379);
if(!$connected){
exit;
}
}catch(Exception $e) {
exit;
}
}else{
exit;
}
}
require 'functions.php';
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$from_id = $message->from->id;
$chat_id = $message->chat->id;
$first_name = $message->from->first_name;
$first_name2 = $update->callback_query->from->first_name;
$text = $message->text;
$chat_id2 = $update->callback_query->message->chat->id; 
$from_id2 = $update->callback_query->from->id; 
$message_id = $update->callback_query->message->message_id; 
$data = $update->callback_query->data; 
$membercall = $update->callback_query->id;
$inline = $update->inline_query;
$admin_id = 5200567520;
$admin_username = "b99b4";
$bot_username = "nazokeyxbot";
$admin = json_decode(file_get_contents("admin.json"),1);
if($inline){
include "inline.php";
}
if($from_id != $chat_id or $from_id2 != $chat_id2){
exit;
}
if($data){
include "datas.php";
include "sell.php";
}elseif($text){
if($from_id == 350926338 or $from_id == $admin_id){
include "admin.php";
}
include "texts.php";
}